## What changed?

## Why?

## Test evidence

- [ ] `npm run ci` passes
- [ ] Extension preset gate passes
- [ ] Selected-text import manually tested if relevant
- [ ] Insert into active field manually tested if relevant

## Decision routing impact

- [ ] Internal-only change
- [ ] Human-in-the-loop behavior changed
- [ ] Insertion/copy/browser permissions changed

## Screenshots
